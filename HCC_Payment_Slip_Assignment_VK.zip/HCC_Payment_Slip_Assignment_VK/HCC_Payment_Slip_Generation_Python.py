
#----Project Title: Payment slips generation for weekly payments of workers using Python --------------
# -------------------------------------------------------------------------------------------------------
# Note: The actual script run starts from line 32 of this python notebook.

# Created by:  Victor Kadiri
# Date Created: 6th March 2025

# Purpose: This python script is created to faciliate the weekly payments of workers at Highride Construction Company (HCC). The script utilizes series of function and statements to generate payment slips for 400 workers.

# Desired Output: The final output will be saved into physical text file "HCC_Payment_Slip_Generation_Python.txt"

# Datasets used: No data input is required to perform this analysis. The python model uses a combination of inbulit functions and series of statements to achieve its purpose.

# Scripts Required: 
# a. HCC_Payment_Slip_Generation_Python.py

# Tools and Installations Required:
# 1. Download and Install VS Code 
# 2. Download and Install Python 3.12.9 or higher

# Procedures Performed:
# 1: Launch the VS Code application
# 2: Download the ZIP folder and Unzip
# 3: Open the script source file (a. HCC_Payment_Slip_Generation_Python.py) using VS code
# 4: Change output folder to your desired location.
# 5: Locate and Click the "Run" button on the script file (a. HCC_Payment_Slip_Generation_Python.py)
# 6: View the outputs on the terminal panes or locate the output txt file from your set output path on your PC.
#--------------------------------------------------------------------------------------------------------

# ----------------------- The Actual Analysis Begins Here -----------------------------------------------
#Step 1: This step import the required libraries and functions required for this analysis
import os
import random

# Step 2: This step is important - Please action the below:
# Set your output folder path (Remember to Change this to your desired output folder path)
output_folder_path = r"C:\Users\User\Downloads\BAN6420\HCC_Payment_Slips"
# The script below creates this output folder path if it does not exist on your PC. This will prevent an error from occuring.
os.makedirs(output_folder_path, exist_ok=True)
# This line of code defines the output file path
output_file_path = os.path.join(output_folder_path, "HCC_Payment_Slip_Generation_Python.txt")

# Step 3: This step creates a list of 400 workers dynamically using the next set of codes.
# The code below initializes an empty list to store worker details
workers = []
# The next code below uses a "for" loop to create 400 workers
for i in range(1, 401):
# The next code create a dictionary for each worker.
    worker = {
# This creates a unique ID for each worker starting from 1 to 400
        "id": i,
# This creates a generic name for each worker (e.g., "Worker_1", "Worker_2")
        "name": f"Worker_{i}",
# The next code randomly selects a gender choice of either a male and female for each worker
        "gender": random.choice(["Male", "Female"]),
# The next code randomly selects a salary for each worker between $5,000 and $35,000
        "salary": random.randint(5000, 35000) 
    }
# The final line of code in this step appends all worker details from the above
    workers.append(worker)

# Step 4: This step allows the generation of payment slips for each worker. The following set of codes are used to achieve this.
# This line of code opens the output file in write mode ('w') to save the HCC payment slips
with open(output_file_path, "w") as output_file:
# This line of code uses a 'for' loop to iterate through each worker in the workers list created above
    for worker in workers:
# This line of code uses a try block to handle potential errors during processing.
        try:
# This line of code extracts the worker ID, name, gender and salary information from the dictionary for further analysis
            worker_id = worker["id"]  
            worker_name = worker["name"]  
            worker_gender = worker["gender"]  
            worker_salary = worker["salary"]  

# Step 5: This step allows the implementation of conditional statements to assign the Employee level per the business requirement. The following set of codes are used.
# This line of code sets the employee level as "Default".
            employee_level = "Default"

# This line of code confirms whether the salary is between $10,000 and $20,000 and if yes "A1" is assigned as the employee level
            if 10000 < worker_salary < 20000:
                employee_level = "A1"

 # This line of code confirms whether the salary is between between $7,500 and $30,000 and the worker is female. If yes, it assigns "A5-F" as the employee level
            elif 7500 < worker_salary < 30000 and worker_gender == "Female":
                employee_level = "A5-F"
# Note that other scenario outside the two conditional statements above are treated as default employee level

# Step 6: This step allows the payment slips to generated as a string for further export to txt
            HCC_payment_slip = (
                f"Worker ID: {worker_id}\n"  
                f"Name: {worker_name}\n"  
                f"Gender: {worker_gender}\n"  
                f"Salary: ${worker_salary}\n"  
                f"Employee Level: {employee_level}\n"  
                f"{'-' * 30}\n"  
            )

# Step 7: This code allows the payment slip to be viewed the terminal below
            print(HCC_payment_slip)

# Step 8: This code allows the payment slip to be exported as a text file.
            output_file.write(HCC_payment_slip)

# Step 9: The final set of codes helps to handle any exceptions that may occur during processing.
        except Exception as e:

# The code displays an error message showing the details of exception and the affected worker ID.
            print(f"Error processing Worker ID {worker_id}: {e}")

# The code displays a confirmation message after all HCC payment slips have been generated.
print(f"HCC Payment slips have been generated and saved to {output_file_path}")