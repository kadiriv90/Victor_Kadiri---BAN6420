# --- Project Title: Payment slips generation for weekly payments of workers using R -------------------
# -------------------------------------------------------------------------------------------------------
# Note: The actual script run starts from line 32 of this R script.

# Created by:  Victor Kadiri
# Date Created: 6th March 2025

# Purpose: This R script is created to facilitate the weekly payments of workers at Highride Construction Company (HCC). 
# The script utilizes a series of functions and statements to generate payment slips for 400 workers.

# Desired Output: The final output will be saved into a physical text file "HCC_Payment_Slip_Generation_R.txt".

# Datasets used: No data input is required to perform this analysis. The R model uses a combination of built-in functions and series of statements to achieve its purpose.

# Scripts Required: 
# a. HCC_Payment_Slip_Generation_R.R

# Tools and Installations Required:
# 1. Download and Install VS Code 
# 2. Download and Install R 4.3.0 or higher

# Procedures Performed:
# 1: Launch the VS Code application
# 2: Download the ZIP folder and Unzip
# 3: Open the script source file (a. HCC_Payment_Slip_Generation_R.R) using VS Code.
# 4: Change the output folder path to your desired location.
# 5: Locate and Click the "Run" button on the script file (a. HCC_Payment_Slip_Generation_R.R)
# 6: View the outputs on the terminal or locate the output txt file from your set output path on your PC.

# ----------------------------------------------------------------------------------------------------
# ----------------------- The Actual Analysis Begins Here -----------------------------------------------
# Step 1: Load required libraries
# No external libraries are required for this R script.

# Step 2: This step is important - Please action the below:
# Set your output folder path (Remember to Change this to your desired output folder path)
output_folder_path <- "C:/Users/User/Downloads/BAN6420/HCC_Payment_Slips"
# The script below creates this output folder path if it does not exist on your PC. This will prevent an error from occuring.
if (!dir.exists(output_folder_path)) {
  dir.create(output_folder_path, recursive = TRUE)
}
# This line of code defines the output file path
output_file_path <- file.path(output_folder_path, "HCC_Payment_Slip_Generation_R.txt")

# Step 3: This step creates a list of 400 workers dynamically using the next set of codes.
# The code below initializes an empty list to store worker details
workers <- list()

# The next code below uses a "for" loop to create 400 workers
for (i in 1:400) {

# The next code creates a dictionary for each worker.
  worker <- list(
# This creates a unique ID for each worker starting from 1 to 400
    id = i,  
# This creates a generic name for each worker (e.g., "Worker_1", "Worker_2")
    name = paste0("Worker_", i), 
# The next code randomly selects a gender choice of either a male and female for each worker
    gender = sample(c("Male", "Female"), 1), 
# The next code randomly selects a salary for each worker between $5,000 and $35,000
    salary = sample(5000:35000, 1) 
  )
# The final line of code in this step appends all worker details from the above
  workers[[i]] <- worker
}

# Step 4: This step allows the generation of payment slips for each worker. The following set of codes are used to achieve this.
# This line of code opens the output file in write mode ('w') to save the HCC payment slips
file_conn <- file(output_file_path, "w")

# This line of code uses a 'for' loop to iterate through each worker in the workers list created above
for (worker in workers) {
# This line of code uses a tryCatch block to handle potential errors during processing.
  tryCatch({
# This line of code extracts the worker ID, name, gender and salary information from the dictionary for further analysis
    worker_id <- worker$id
    worker_name <- worker$name
    worker_gender <- worker$gender
    worker_salary <- worker$salary

# Step 5: This step allows the implementation of conditional statements to assign the Employee level per the business requirement. The following set of codes are used.
# This line of code sets the employee level as "Default".
    employee_level <- "Default"

# This line of code confirms whether the salary is between $10,000 and $20,000 and if yes "A1" is assigned as the employee level
    if (worker_salary > 10000 && worker_salary < 20000) {
      employee_level <- "A1"

# This line of code confirms whether the salary is between between $7,500 and $30,000 and the worker is female. If yes, it assigns "A5-F" as the employee level
    } else if (worker_salary > 7500 && worker_salary < 30000 && worker_gender == "Female") {
      employee_level <- "A5-F"
    }

# Note that other scenario outside the two conditional statements above are treated as default employee level

# Step 6: This step allows the payment slips to generated as a string for further export to txt
    HCC_payment_slip <- paste(
      "Worker ID:", worker_id, "\n",
      "Name:", worker_name, "\n",
      "Gender:", worker_gender, "\n",
      "Salary: $", worker_salary, "\n",
      "Employee Level:", employee_level, "\n",
      paste(rep("-", 30), collapse = ""), "\n",
      sep = ""
    )

# Step 7: This code allows the payment slip to be viewed the terminal below
    cat(HCC_payment_slip)

# Step 8: This code allows the payment slip to be exported as a text file.
    writeLines(HCC_payment_slip, file_conn)

# Step 9: The final set of codes helps to handle any exceptions that may occur during processing.
  }, error = function(e) {

# The code displays an error message showing the details of exception and the affected worker ID.
    cat("Error processing Worker ID", worker_id, ":", e$message, "\n")
  })
}

# This code closes the output file connection
close(file_conn)

# The code displays a confirmation message after all HCC payment slips have been generated.
cat("HCC Payment slips have been generated and saved to", output_file_path, "\n")